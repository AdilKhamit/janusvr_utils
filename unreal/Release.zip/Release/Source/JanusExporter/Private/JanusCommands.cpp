#include "FJanusExporterModulePrivatePCH.h"
#include "JanusCommands.h"

#define LOCTEXT_NAMESPACE "JanusExporter"

void FJanusCommands::RegisterCommands()
{
	//UI_COMMAND(TestCommand, "Test Command", "Performs a test command", EUserInterfaceActionType::Button, FInputGesture());
}

#undef LOCTEXT_NAMESPACE
